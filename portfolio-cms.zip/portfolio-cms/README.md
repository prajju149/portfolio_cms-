# portfolio-cms (Strapi scaffold)

This folder contains a minimal scaffold and scripts to help bootstrap a Strapi project for the portfolio example.

**Important**: This is *not* a full Strapi binary install. To create a working Strapi app, run:

```bash
npx create-strapi-app@latest portfolio-cms --quickstart
```

Then copy files from this `scaffold` into the generated `portfolio-cms` or follow the instructions below.

## What is included
- `sample-data/projects.json` — sample Project entries
- `scripts/import-sample-data.js` — Node script to import the sample data into a running Strapi instance
- `.env.example` — example env for Strapi tokens
- `content-types/` — JSON examples of content-type definitions (for reference)

## Quick start to load sample data into Strapi

1. Create a Strapi project and run it locally:
   ```bash
   npx create-strapi-app@latest portfolio-cms --quickstart
   cd portfolio-cms
   npm run develop
   ```

2. Create an API token in Strapi Admin (Settings → API Tokens) with `create` permissions for `Project` and `About`.
   - Copy the token and set it in `.env` (or export as STRAPI_TOKEN environment variable).

3. From this scaffold folder, run the sample-import script:
   ```bash
   node scripts/import-sample-data.js
   ```

The script will POST sample Projects and About data via Strapi REST endpoints.

