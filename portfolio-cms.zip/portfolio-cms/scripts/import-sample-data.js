/**
 * Usage:
 * 1. Start your Strapi instance (http://localhost:1337)
 * 2. Create an API token in Strapi Admin with create permissions for Project and About
 * 3. Set STRAPI_TOKEN env var or edit this script to add token
 * 4. node scripts/import-sample-data.js
 */

const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');

const STRAPI_URL = process.env.STRAPI_URL || 'http://localhost:1337';
const TOKEN = process.env.STRAPI_TOKEN || '';

if (!TOKEN) {
  console.error('Please set STRAPI_TOKEN env var (API token with create permissions).');
  process.exit(1);
}

async function post(endpoint, body) {
  const res = await fetch(`${STRAPI_URL}/api/${endpoint}`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${TOKEN}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) {
    console.error('Error', endpoint, data);
  } else {
    console.log('Created', endpoint, data);
  }
  return data;
}

async function main() {
  const projects = JSON.parse(fs.readFileSync(path.join(__dirname, '../sample-data/projects.json')));
  for (const p of projects) {
    await post('projects', { data: p });
  }
  const about = JSON.parse(fs.readFileSync(path.join(__dirname, '../sample-data/about.json')));
  // About is a single type; create or update depends — we'll try POST to /about
  await post('about', { data: about });
  console.log('Done.');
}

main().catch(console.error);
