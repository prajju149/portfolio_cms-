import { gql } from '@apollo/client';
import client from '@/lib/apollo';
import Link from 'next/link';

const PROJECTS_QUERY = gql`
  query {
    projects(pagination: { limit: 10 }) {
      data {
        id
        attributes {
          title
          slug
          description
        }
      }
    }
  }
`;

export default function Home({ projects }: any) {
  return (
    <main style={{ padding: 20 }}>
      <h1>My Portfolio</h1>
      <ul>
        {projects.map((p: any) => (
          <li key={p.id}>
            <Link href={`/projects/${p.attributes.slug}`}><a>{p.attributes.title}</a></Link>
          </li>
        ))}
      </ul>
    </main>
  );
}

export async function getStaticProps() {
  const { data } = await client.query({ query: PROJECTS_QUERY });
  return { props: { projects: data.projects.data }, revalidate: 60 };
}
