import { GetStaticPaths, GetStaticProps } from 'next';
import { fetchAPI } from '@/lib/api';
import client from '@/lib/apollo';
import { gql } from '@apollo/client';

export default function ProjectPage({ project, preview }: any) {
  if (!project) return <p>Not found</p>;
  return (
    <div style={{ padding: 20 }}>
      {preview && <div style={{ background: 'yellow', padding: 8 }}>Preview Mode</div>}
      <h1>{project.title}</h1>
      <div dangerouslySetInnerHTML={{ __html: project.description }} />
    </div>
  );
}

export const getStaticPaths: GetStaticPaths = async () => {
  const QUERY = gql`query { projects(pagination: { limit: 100 }) { data { attributes { slug } } } }`;
  const { data } = await client.query({ query: QUERY });
  const paths = data.projects.data.map((p: any) => ({ params: { slug: p.attributes.slug } }));
  return { paths, fallback: 'blocking' };
};

export const getStaticProps: GetStaticProps = async ({ params, preview }) => {
  const slug = params?.slug as string;
  const headers = preview ? { Authorization: `Bearer ${process.env.STRAPI_PREVIEW_TOKEN}` } : {};
  const data = await fetchAPI(`/projects?filters[slug][$eq]=${slug}`, { headers });
  const attrs = data.data?.[0]?.attributes || null;
  return { props: { project: attrs, preview: !!preview }, revalidate: 60 };
};
