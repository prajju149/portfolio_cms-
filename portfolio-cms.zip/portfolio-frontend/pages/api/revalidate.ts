import type { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const secret = process.env.REVALIDATE_SECRET;
  // Support header x-strapi-secret or query param
  const incoming = req.headers['x-strapi-secret'] || req.query.secret;
  if (incoming !== secret) {
    return res.status(401).json({ message: 'Invalid secret' });
  }
  try {
    const slug = req.body?.entry?.slug;
    if (slug && typeof slug === 'string') {
      await res.revalidate(`/projects/${slug}`);
    }
    await res.revalidate('/');
    return res.json({ revalidated: true });
  } catch (err) {
    return res.status(500).json({ message: 'Error revalidating', err: String(err) });
  }
}
