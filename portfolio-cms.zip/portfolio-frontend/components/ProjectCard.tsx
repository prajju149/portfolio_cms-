import Link from 'next/link';

export default function ProjectCard({ p }: any) {
  return (
    <article style={{ border: '1px solid #ddd', padding: 12, borderRadius: 6 }}>
      <h3><Link href={`/projects/${p.attributes.slug}`}><a>{p.attributes.title}</a></Link></h3>
      <div dangerouslySetInnerHTML={{ __html: p.attributes.description }} />
    </article>
  );
}
