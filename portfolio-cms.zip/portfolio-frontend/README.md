# portfolio-frontend (Next.js + Apollo GraphQL)

Quick start after unzipping:

1. cd portfolio-frontend
2. npm install
3. copy `.env.local.example` to `.env.local` and set values
4. npm run dev

This app uses Apollo Client to query the Strapi GraphQL endpoint.
