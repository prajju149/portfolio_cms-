export async function fetchAPI(path: string, options: any = {}) {
  const base = process.env.NEXT_PUBLIC_STRAPI_REST || 'http://localhost:1337/api';
  const url = `${base}${path}${path.includes('?') ? '&' : '?'}populate=*`;
  const res = await fetch(url, {
    headers: options.headers || {},
    method: options.method || 'GET',
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch ${url}: ${await res.text()}`);
  }
  return res.json();
}
